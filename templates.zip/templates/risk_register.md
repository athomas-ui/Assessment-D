# Risk Register -- [Team / Project] -- Sprint 2 Demo

List at least three risks. For each: probability, impact, a specific
mitigation, and an owner. Open a backlog issue for each risk and link
it in the Issue column.

Probability / Impact scale: Low | Medium | High

| # | Risk | Probability | Impact | Mitigation | Owner | Issue |
|---|------|-------------|--------|------------|-------|-------|
| 1 |Api not Connected  | [Low] | [High] | [Restarting via vscode or pycharm commands] | [Ray] | [1] |
| 2 | [Battery Issue w/Laptop] | [Low] | [Low] | [Charging] | [Full team] | [2] |
| 3 | [Canva system outage] | [High] | [Med] | [Keeping a copy locally as ppt in case( rollback )] |  [Andrew] | [3] |
| 4 | [Cascade Feed not showing Ai Feed] | [Med] | [Restart ollama loccaly and veify operation] | | [ Ray]

## Notes
- Make risks specific (e.g. "live API returns 500 during the demo"),
  not generic ("something breaks").
- A good mitigation is an action someone can take now or on demo day.
- Advanced: add systemic risks and mitigations such as backups,
  monitoring, and rollback.
