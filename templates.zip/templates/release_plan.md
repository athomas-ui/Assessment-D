# Release Plan -- [Cascade]

System context: [API] + [DB] + [UI].

## 1. Pre-flight checklist
- [ ] Environment variables / secrets set (.env, not committed)
- [ ] Database migration dry-run passes
- [ ] Health check green on staging
- [ ] Credentials verified
- [ ] Backup / snapshot taken
- [ ] [Verify api , ai and version]

## 2. Release steps (in order)
1. [V.5]
2. [deploy to staging in docker]
3. [Tests: cd server; .venv\Scripts\python.exe -m pytest -q (they use their own MedlineOPN_Test database)]
4. [http://localhost:8080 (demo password cascade-demo).]
5. [verify /health returns 200]
6. [announce the release in [Allstars Teams Chat]]

## 3. Rollback
Rollback trigger (be specific -- what makes you roll back):
- [ If Cascade ui resembles previous ui layouts or not following RBAC]

Rollback steps:
1. [redeploy the last green release vN-4]
2. [confirm /health returns 200]
3. [start action queue , wait for results to populate]

## 4. Monitoring signals
- Health check: [http://localhost:5173] every [30s]
- Error rate: alert if > [2%]
- Latency: p95 under [X] ms
- [Action Queue and Live Feed]

## 5. Roles and escalation
- Release owner: [RayMond Hall]
- On-call: [Ben Coppage]
- Comms: [Freeda]
- Escalation path: on-call -> [Andrew Thomas] -> [Freeda] if not
  resolved in [45] min
