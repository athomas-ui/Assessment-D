# Incident Log -- [System Name]

One entry per incident. Keep it factual and time-stamped. For the
assessment you may fill in the template or add one simulated entry.

## Template
- Incident ID: INC-001
- Date / time (start): 2026-11-25 14:10
- Detected by: Smoke test after merge (Lead Software Architect)
- Severity: Critical
- Summary: A bulk upload refactor merged to main crashed CASCADE on launch, before the login screen loaded.
- Impact: Main was unusable for all four team members; Dry Run 2 prep was blocked.
- Rollback trigger met: Yes -- "A merge to main breaks the smoke test"
- Actions taken:
    1. Architect paused all merges to main and posted in team chat.
    2. Found the bad commit with `git log`.
    3. Ran `git revert <commit>` and pushed (no force-push).
    4. Made a fresh clone of main and reran the smoke test: pass.
    5. Release lead logged the incident and assigned the fix.
- Resolved (time): 2026-11-25 14:45
- Root cause: The refactor renamed an environment variable without updating .env.example, and it merged without a reviewed pull request.
- Follow-up / post-incident: Every merge to main now needs a reviewed PR and a passing smoke test. .env.example was updated. Refactor reworked on its own branch and re-merged after review.

## Example entry (simulated)
- Incident ID: INC-002
- Date / time (start): 2026-11-30 10:20
- Detected by: Presenter (AI pattern detection still loading after 30 seconds)
- Severity: High
- Summary: The AI pattern detection call timed out twice on the venue's guest Wi-Fi during Dry Run 2.
- Impact: The AI analysis part of the demo couldn't run live; the rest of the demo worked.
- Rollback trigger met: Yes -- "Two or more failures, or AI/API service down"
- Actions taken:
    1. Release lead applied the 30-second rule and called Level 1 (skip and narrate with a screenshot).
    2. The second AI call failed, so release lead called Level 5 (recorded video for the AI part only).
    3. Presenter used the scripted line and went back to the live app for the Problem Register.
- Resolved (time): 2026-11-30 10:24 (demo continued); network cause confirmed 2026-11-30 13:00
- Root cause: The guest network blocked outbound calls to the AI service. We hadn't tested an AI call on the venue network beforehand.
- Follow-up / post-incident: Add "test one AI call on the venue network" to the T-60 checklist. Data & AI Lead builds a cached-response mode. Bring a phone hotspot as a backup network.
